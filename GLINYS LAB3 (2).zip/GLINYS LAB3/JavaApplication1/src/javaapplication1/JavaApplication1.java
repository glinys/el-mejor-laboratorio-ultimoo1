/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;
import java.util.Scanner;
/**
 *
 * @author estudiante
 */
public class JavaApplication1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
      int A;
      
      System.out.println("Escriba cualquier numero");
      Scanner D1 = new Scanner(System.in);
     A = D1.nextInt();
     
      if(A%2==0){
          System.out.println("ES numero par");
      }
      else{
          System.out.println("ES numero impar");
      }
    }
    
}
